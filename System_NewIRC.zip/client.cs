function fixNewChat_C()
{
	discoverfile("add-ons/System_NewIRC.zip");
	exec("add-ons/System_NewIRC/client.cs");
}

if(isObject(BLConnectGui))
{
	BLConnectGui.deleteAll();
	BLConnectGui.delete();
}

if(isObject(BLConnectTCP))
	BLConnectTCP.delete();
	
new TCPObject(BLConnectTCP) {
	site = "www.blocklandconnected.com";
	port = 80;
};
//BLConnectTCP.connect(BLConnectTCP.site @ ":" @ BLConnectTCP.port);
$BLConnect::CreditMessage = "Credits for BLConnect: <br>Visolator (Started off the project and coded alot) <br>tetronaught (Coded alot of stuff) <br>Pacnet (For helping with TCP objects) <br>LeetZero (For the logo) <br> Trinick (For just being good ol' Trinick)";

exec("./Gui/BLConnectGui.gui");
exec("./Gui/BlockoIRC.gui");

BLConnectGui.add(BlockoIRC);
GlobalActionMap.bind(keyboard, "F3", "BLConnect_OpenOverlay");

function BLConnectTCP::onConnected(%this) {
	echo("Yay, it's connected");
}

//Pacnet's code

function BlockoIRC_Send(%text) 
{
        //this is called when the client presses send
        %text = stripMLControlChars(%text);
        if(%text $= "" || %text $= " ") 
        {
                textDisplayIRC.addText("<br>You must type somthing!",1);
                return; //Do not continue if there is an issue
        }
        
        if(toggleInput.getValue() == 1) //Look at the send variable on the TCP for an example
                textDisplayIRC.addText("<br>" @ getNumKeyID() SPC "~" SPC $Pref::Player::NetName @ ":" SPC %text,1);
        else
                textDisplayIRC.addText("<br>" @ $Pref::Player::NetName @ ": " SPC %text,1);
        if(BLConnectTCP.isConnected)
                BLConnectTCP.send("GET /index.php?IRC=SEND%20" @ $Pref::Player::NetName @ "%20:%20" @ %text @ " HTTP/1.0\r\nHost: www.blocklandconnect.com\r\n\r\n");
        else
        {
                echo("NOT CONNECTED TO IRC, CONNECTING...");
                BLConnectTCP.connect(BLConnectTCP.site @ ":" @ BLConnectTCP.port);
                //This is how urls work
                //For spaces, they have to be replaced with %20
                %name = strReplace(%name," ","%20");
                %text = strReplace(%text," ","%20");
                BLConnectTCP.message = "GET /index.php?IRC=SEND%20" @ $Pref::Player::NetName @ "%20:%20" @ %text @ " HTTP/1.0\r\nHost: www.blocklandconnect.com\r\n\r\n";
        }
        textInput.setText("");
}

//TCP

function BLConnectTCP::onLine(%this,%l)
{
        %this.lineCount++; //Line count, so you can see what line it will be for special purposes
        if(getWord(%l,0) $= "SEND")
                textDisplayIRC.addText("<br>" @ getWords(%l,1,getWordCount(%l)) @ " - Sent",1);
        echo(%this.lineCount @ " > " @ %l);
}

function BLConnectTCP::onConnected(%this)
{
        %this.lineCount = 0; //It will echo line 1 as the first line
        %this.isConnected = 1;
        %this.send(%this.message); //See line 25
        %this.message = "";
        echo("CONNECTED - SENDING INFORMATION");
}

function BLConnectTCP::onDisconnect(%this)
{
        %this.isConnected = 0;
        echo("DISCONNECTED");
}


function BLConnectGui::OnSleep(%this)
{
	%this.res = getWord(getRes(),0) SPC getWord(getRes(),1);
	%this.extent = %this.res;
	BLConnect_Connect_ID.setText("ID: " @ getNumKeyID());
	BLConnect_Connect_Name.setText("<just:center>" @ $Pref::Player::NetName);
}

function BLConnectGui::BindKey(%this,%key)
{
	%binding = GlobalActionMap.getBinding("BLConnect_toggleOverlay");
	GlobalActionMap.unbind(getField(%binding,0),getField(%binding,1));
	GlobalActionMap.bind(keyboard,%key,"BLConnect_toggleOverlay");
	BLConnect_SavePref("ToggleOverlay::KeyBind",%key);
}

function BLConnect_Overlay::onSleep(%this)
{
   GlobalActionMap.unbind("keyboard","escape");
   
	for(%i=0;%i<%this.getCount();%i++)
	{
      %ctrl = %this.getObject(%i);
         
      if(%ctrl.getName() !$= "")
      {
         $BLConnect::WindowPosition[%ctrl.getName()] = %ctrl.position;
         $BLConnect::WindowExtent[%ctrl.getName()] = %ctrl.extent;
      }
	}
}


//toggle window

$toggle = 0;

function BLConnect_OpenOverlay(%key){
	if (%key == 1) {
		
		if ($toggle == 1) {
			canvas.popDialog(BLConnectGui);
			$toggle = 0;
		} else {
			BLConnectTCP.connect("www.blocklandconnected.com:80");
			canvas.pushDialog(BLConnectGui);
			$toggle = 1;
		}
	}
}
function BLConnect_SavePref(%pref,%value){eval("$BLConnect::" @ %pref @ " = " @ %value @ ";");BLConnect_SavePrefs();}
function BLConnect_SavePrefs(){export("$BLConnect::*","config/client/BLConnectPrefs.cs");}

function BLConnect_Connect_Accept()
{
	if(%call)
		eval(BLConnect_Connect_Message.lastCmd);
	else
		BLConnectTCP.send(BLConnect_Connect_Message.lastCmd);
	BLConnect_Connect_Message.lastCmd = "";
}

function BLConnect_Connect_CloseMessageBox(){BLConnect_Connect_Message.setVisible(0);}

function BLConnect_Connect_Message(%yesNo,%boxM,%msg,%color,%cmd)
{
	if(%type == true)
	{
		BLConnect_Connect_MessageYes.setVisible(1);
		BLConnect_Connect_MessageNo.setVisible(1);
		BLConnect_Connect_MessageOk.setVisible(0);
	}
	else
	{
		BLConnect_Connect_MessageYes.setVisible(0);
		BLConnect_Connect_MessageNo.setVisible(0);
		BLConnect_Connect_MessageOk.setVisible(1);
	}
	BLConnect_Connect_MessageBox.setText(%boxM);
	BLConnect_Connect_MessageText.setText("<just:center>" @ %msg);
	BLConnect_Connect_Message.color = getWords(%color,0,2) @ "255";
	BLConnect_Connect_Message.lastCmd = %cmd;
}